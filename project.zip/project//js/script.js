 document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();

            const nama = document.getElementById('nama').value;
            const email = document.getElementById('email').value;
            const tanggal = document.getElementById('date').value;
            const gender = document.getElementById('gender').value;

            const tbody = document.getElementById('datatable').querySelector('tbody');
            const row = tbody.insertRow();
            row.insertCell(0).textContent = nama;
            row.insertCell(1).textContent = email;
            row.insertCell(2).textContent = tanggal;
            row.insertCell(3).textContent = gender;

            document.getElementById('registerForm').reset();
        });